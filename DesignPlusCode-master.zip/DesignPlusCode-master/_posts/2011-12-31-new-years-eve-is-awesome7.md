---
layout: default
title: New years eve is awesome
thumbnail: post-8.jpg
---

# Goodbye cruel word
