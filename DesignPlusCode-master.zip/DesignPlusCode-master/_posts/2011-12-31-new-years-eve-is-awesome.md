---
layout: default
title: New years eve is awesome
thumbnail: post-1.png
---

# Goodbye cruel word
