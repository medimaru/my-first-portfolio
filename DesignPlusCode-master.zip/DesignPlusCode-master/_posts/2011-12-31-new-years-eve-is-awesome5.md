---
layout: default
title: New years eve is awesome
thumbnail: post-6.gif
---

# Goodbye cruel word
